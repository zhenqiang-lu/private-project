define(function(require, exports, module) {
  module.exports = {
    english: require('./en.js'),
    chinese: require('./zh.js')
  }
})