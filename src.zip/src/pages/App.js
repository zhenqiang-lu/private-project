define(function(require, exports, module) {
  module.exports = Vue.component('App', {
    template: '<router-view></router-view>'
  })
})
